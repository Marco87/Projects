# QuarentenaDados

Repositório com os notebooks das aulas e dados e código do desafio final (arquivo zip).
