# Used for an example only

def my_useful_function():
  print("hello world")